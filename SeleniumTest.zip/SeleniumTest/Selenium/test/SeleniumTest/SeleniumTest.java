/**
 * 
 */
package SeleniumTest;

import com.test.Selenium;

/**
 * @author Vikram.UK
 *
 */
public class SeleniumTest {

	public static Selenium seleniumTest;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Selenium.Echo();
		}

}
