/**
 * 
 */
package com.test;

/**
 * @author Vikram.UK
 *
 */
public class Selenium {
	/**
	 * @param args
	 */
	public static void Echo() {
			System.out.println("Echo");
	}

}
