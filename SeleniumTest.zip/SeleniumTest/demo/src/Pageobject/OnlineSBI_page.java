package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OnlineSBI_page {

	public static void main(String[] args) {

		String exePath = "C:\\ProgApps\\Lib\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver driver = new ChromeDriver();
		String url = "https://retail.onlinesbi.com/retail/mcashclaimwin.htm?bankCode=0";
		driver.get(url);		
		onlinesbi_loginPage.txt_acct_name(driver).sendKeys("vikram.uk@yahoo.com");
		onlinesbi_loginPage.txt_ifsc_code(driver).sendKeys("Test");
		onlinesbi_loginPage.btn_selectOTP(driver).click();
		onlinesbi_loginPage.txt_mobile(driver).sendKeys("9916028682");
		onlinesbi_loginPage.txt_passcode(driver).sendKeys("0123456");
		onlinesbi_loginPage.btn_submit(driver).click();
	}
}
