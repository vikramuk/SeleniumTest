package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class onlinesbi_loginPage {

		private static WebElement e = null;
		public static WebElement txt_acct_name(WebDriver driver) {
			e = driver.findElement(By.id("creditAcc"));
			return e;
		}

		public static WebElement txt_ifsc_code(WebDriver driver) {
			e = driver.findElement(By.name("ifsc"));
			return e;
		}

		public static WebElement btn_selectOTP(WebDriver driver) {
			e =  driver.findElement(By.name("selectOTP"));
			return e;
		}
		public static WebElement txt_mobile(WebDriver driver) {
			e =  driver.findElement(By.name("benMobNo"));
			return e;
		}
		public static WebElement txt_passcode(WebDriver driver) {
			e =  driver.findElement(By.name("passcode"));
			return e;
		}
		public static WebElement btn_submit(WebDriver driver) {
			e =  driver.findElement(By.name("Submit"));
			return e;
		}
	}

	
