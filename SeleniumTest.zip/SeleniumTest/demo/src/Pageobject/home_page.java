package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class home_page {

	public static void main(WebDriver Driver) {

	Element = Driver.findElement(By.name("signin"));
		
		
	}

}
