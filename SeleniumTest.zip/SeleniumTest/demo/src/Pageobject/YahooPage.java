package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class YahooPage {

	public static void main(String[] args) {

		String exePath = "C:\\ProgApps\\Lib\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver driver = new ChromeDriver();
		String url = "https://login.yahoo.com/config/login?.src=fpctx&.intl=in&.lang=en-IN&.done=https%3A%2F%2Fin.yahoo.com";
		driver.get(url);
		
		yahoo_loginPage.txt_login_name(driver).sendKeys("vikramupadhya@yahoo.com");
		yahoo_loginPage.btn_login_next(driver).click();
		yahoo_loginPage.txt_login_password(driver).sendKeys("Password");
		yahoo_loginPage.btn_login_submit(driver).click();
		
		
	}
}
