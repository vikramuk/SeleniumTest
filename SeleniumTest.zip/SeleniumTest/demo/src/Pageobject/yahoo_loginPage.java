package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class yahoo_loginPage {

		private static WebElement e = null;
		public static WebElement txt_login_name(WebDriver driver) {
			e = driver.findElement(By.id("login-username"));
			return e;
		}

		public static WebElement btn_login_next(WebDriver driver) {
			e = driver.findElement(By.id("login-signin"));
			return e;
		}

		public static WebElement txt_login_password(WebDriver driver) {
			e =  driver.findElement(By.xpath("//*[@id=\"login-passwd\"]"));
			return e;
		}
		public static WebElement btn_login_submit(WebDriver driver) {
			e =  driver.findElement(By.id("login-signin"));
			return e;
		}
	}

	
