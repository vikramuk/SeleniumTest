package Pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class amazon_loginPage {

		private static WebElement e = null;
		public static WebElement txt_login_name(WebDriver driver) {
			e = driver.findElement(By.id("ap_email"));
			return e;
		}

		public static WebElement btn_login_next(WebDriver driver) {
			e = driver.findElement(By.id("continue"));
			return e;
		}

		public static WebElement txt_login_password(WebDriver driver) {
			e =  driver.findElement(By.name("signin"));
			return e;
		}
		public static WebElement btn_login_submit(WebDriver driver) {
			e =  driver.findElement(By.name("login"));
			return e;
		}
	}

	
