package sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class test {

	public static void main(String[] args) {
		String exePath = "C:\\ProgApps\\Lib\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com");
        WebElement element = driver.findElement(By.name("q"));	
        element.sendKeys("Test");					
        element.submit();         			
        System.out.println("Page title is: " + driver.getTitle());		
        driver.quit();	
		
	}
}
