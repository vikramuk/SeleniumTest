package sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class ChromeOptions {

	public static void main(String[] args) {
		String exePath = "C:\\ProgApps\\Lib\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver driver = new ChromeDriver();
		// Add a ChromeDriver-specific capability.
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		driver.get("https://www.calculator.net");
		// Select Normal Calculator
        WebElement element = driver.findElement(By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[3]/span[1]"));	
		System.out.println(element.getClass().getName());
	

		
	}
}
