package sample;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Calculatortest {

	/**
 * @param driver
 */
public static void loadElements(WebDriver driver) {
	WebElement Sin = driver.findElement(
			By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[1]/div/div[1]/span[1]"));
	WebElement Cos = driver.findElement(
			By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[1]/div/div[1]/span[2]"));
	WebElement Tan = driver.findElement(
			By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[1]/div/div[1]/span[3]"));
	WebElement InvSin = driver.findElement(
			By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[1]/div/div[2]/span[1]"));
	WebElement InvCos = driver.findElement(
			By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[1]/div/div[2]/span[2]"));
	WebElement InvTan = driver.findElement(
			By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[1]/div/div[2]/span[3]"));
}

public static void main(String[] args) {
	Boolean debug = true;
	String Url= "https://www.calculator.net/take-home-pay-calculator.html";
	String exePath = "C:\\ProgApps\\Lib\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver", exePath);
	WebDriver driver = new ChromeDriver();
	driver.get(Url);
	// Select Normal Calculator
	//loadElements(driver);

	Select selectPercent = new Select(driver.findElement(By.xpath("//*[@id=\"cpayfrequency\"]")));
	selectPercent.selectByVisibleText("Daily");
	
	Select dropDown = new Select(driver.findElement(By.xpath("//*[@id=\"cfilestatus\"]")));
	List<WebElement> e = dropDown.getOptions();
	int itemCount = e.size();
	for(int l = 0; l < itemCount; l++)
	{
	    System.out.println(e.get(l).getText());
	}
	String CheckContractorValue = "";
	
	WebElement exz = driver.findElement(By.name("cadditionat1"));
	String expected = "Yes";
	String actual = exz.getText();
	System.out.println("Actual value = " + actual);
	if(expected.equals(exz)) {
		exz.click();
	}
	
	//CheckContractor.selectByVisibleText("Yes");
	System.out.println("Yes Selected");
/*	
	WebElement element = driver.findElement(By.xpath("//*[@id=\"scirdsettingr\"]"));
	WebElement element2;
	element.click();
	element2 = driver.findElement(
			By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
	element2.click();

	// Check for Output
	WebElement output;
	output = driver.findElement(By.xpath("//*[@id=\"sciOutPut\"]"));
	output.getText();
	int Output = Integer.parseInt(output.getText());
	assertEquals(2,Output);
	if (debug) {
		System.out.println(output.getClass().getName());
	}
	*/
	// Select a specific Type of Calculator
	//		WebElement element2 = driver.findElement(By.xpath("/html/body/div[4]/div/table/tbody/tr/td[1]/ul/li[5]/a/html/body/div[4]/div/table/tbody/tr/td[1]/ul/li[5]/a"));
	//		System.out.println(element2.getClass().getName());
	//        System.out.println("Page title is: " + driver.getTitle());		
	
	}
}
