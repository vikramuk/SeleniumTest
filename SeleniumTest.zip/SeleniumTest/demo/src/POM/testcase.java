package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class testcase {

	public static void main(String[] args) {
		String Url= "https://www.calculator.net/take-home-pay-calculator.html";
		String exePath = "C:\\ProgApps\\Lib\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver driver = new ChromeDriver();
		driver.get(Url);

	}

}
